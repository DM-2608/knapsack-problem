from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    if request.method == 'POST':
        try:
            items = []
            
            box_capacity = []
            item_counter = 0
            #...............For items volume...................
            while f'{item_counter}_height' in request.POST:
                height = float(request.POST[f'{item_counter}_height'])
                width = float(request.POST[f'{item_counter}_width'])
                length = float(request.POST[f'{item_counter}_length'])
                volume = int((height * width * length) /5000)
                items.append(volume)
                item_counter += 1

            item_counter = 0
            # ................For box Capicity List................
            while f'big_box_capacity_{item_counter}' in request.POST:
                box = float(request.POST[f'big_box_capacity_{item_counter}'])
                box_capacity.append(box)
                item_counter += 1

            # ............algo for solve problem........................
            def knapsack(items, box_capacity):
                items.sort(reverse=True)
                boxes = []
                for capacity in box_capacity:
                    box = [capacity, []]
                    boxes.append(box)

                

                for item in items:
                    for box in boxes:
                        if item <= box[0]:
                            box[1].append(item)
                            box[0] -= item
                            break

                return boxes

            boxes = knapsack(items, box_capacity)

            result = []
            for i, box in enumerate(boxes):
                 result.append(f"box {i + 1} (Remaining Capacity {box[0]}): {box[1]}")

            return render(request, 'knapsackview.html', {'compute': result})

        except (ValueError, KeyError) as e:
            return render(request, 'knapsackview.html', {'error': 'An error occurred during processing.'})

    return render(request, 'knapsackview.html')
