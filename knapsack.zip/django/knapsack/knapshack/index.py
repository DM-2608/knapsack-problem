
from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    if request.method == 'POST':
        try:
            items = []
            item_counter = 0
            while f'item_{item_counter}_height' in request.POST:
                height = float(request.POST[f'item_{item_counter}_height'])
                width = float(request.POST[f'item_{item_counter}_width'])
                length = float(request.POST[f'item_{item_counter}_length'])
                volume = height * width * length
                items.append(volume)
                item_counter += 1


            return render(request, 'knapsackview.html', {'compute': bin})

           
        except (ValueError, KeyError) as e:
            # Handle the case where conversion fails or keys are missing
            return render(request, 'knapsackview.html', {'error madarchod': str(e)})

    return render(request, 'knapsackview.html')





